using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace Zo.ShootingRange.Pages
{
    public class IndexModel : AbpPageModel
    {
        public void OnGet()
        {
        }
    }
}
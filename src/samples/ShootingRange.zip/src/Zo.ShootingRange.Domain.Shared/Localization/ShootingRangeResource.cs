﻿using Volo.Abp.Localization;

namespace Zo.ShootingRange.Localization
{
    [LocalizationResourceName("ShootingRange")]
    public class ShootingRangeResource
    {

    }
}
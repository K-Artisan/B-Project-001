﻿using Zo.ShootingRange.EntityFrameworkCore;
using Volo.Abp.Autofac;
using Volo.Abp.BackgroundJobs;
using Volo.Abp.Modularity;

namespace Zo.ShootingRange.DbMigrator
{
    [DependsOn(
        typeof(AbpAutofacModule),
        typeof(ShootingRangeEntityFrameworkCoreDbMigrationsModule),
        typeof(ShootingRangeApplicationContractsModule)
        )]
    public class ShootingRangeDbMigratorModule : AbpModule
    {
        public override void ConfigureServices(ServiceConfigurationContext context)
        {
            Configure<AbpBackgroundJobOptions>(options => options.IsJobExecutionEnabled = false);
        }
    }
}

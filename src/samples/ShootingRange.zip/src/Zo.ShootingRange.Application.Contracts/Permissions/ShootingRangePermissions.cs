﻿namespace Zo.ShootingRange.Permissions
{
    public static class ShootingRangePermissions
    {
        public const string GroupName = "ShootingRange";

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";
    }
}
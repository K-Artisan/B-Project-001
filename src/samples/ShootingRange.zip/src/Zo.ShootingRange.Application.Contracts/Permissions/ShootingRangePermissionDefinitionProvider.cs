﻿using Zo.ShootingRange.Localization;
using Volo.Abp.Authorization.Permissions;
using Volo.Abp.Localization;

namespace Zo.ShootingRange.Permissions
{
    public class ShootingRangePermissionDefinitionProvider : PermissionDefinitionProvider
    {
        public override void Define(IPermissionDefinitionContext context)
        {
            var myGroup = context.AddGroup(ShootingRangePermissions.GroupName);

            //Define your own permissions here. Example:
            //myGroup.AddPermission(ShootingRangePermissions.MyPermission1, L("Permission:MyPermission1"));
        }

        private static LocalizableString L(string name)
        {
            return LocalizableString.Create<ShootingRangeResource>(name);
        }
    }
}

﻿using System.Threading.Tasks;

namespace Zo.ShootingRange.Data
{
    public interface IShootingRangeDbSchemaMigrator
    {
        Task MigrateAsync();
    }
}

﻿namespace Zo.ShootingRange.Settings
{
    public static class ShootingRangeSettings
    {
        private const string Prefix = "ShootingRange";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}
﻿using Volo.Abp.Settings;

namespace Zo.ShootingRange.Settings
{
    public class ShootingRangeSettingDefinitionProvider : SettingDefinitionProvider
    {
        public override void Define(ISettingDefinitionContext context)
        {
            //Define your own settings here. Example:
            //context.Add(new SettingDefinition(ShootingRangeSettings.MySetting1));
        }
    }
}

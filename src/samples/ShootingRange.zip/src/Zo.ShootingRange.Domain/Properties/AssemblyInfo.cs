﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Zo.ShootingRange.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("Zo.ShootingRange.TestBase")]

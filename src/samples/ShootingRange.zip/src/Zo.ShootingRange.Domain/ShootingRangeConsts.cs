﻿namespace Zo.ShootingRange
{
    public static class ShootingRangeConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}

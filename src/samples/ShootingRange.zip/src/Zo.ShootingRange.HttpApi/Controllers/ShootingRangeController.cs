﻿using Zo.ShootingRange.Localization;
using Volo.Abp.AspNetCore.Mvc;

namespace Zo.ShootingRange.Controllers
{
    /* Inherit your controllers from this class.
     */
    public abstract class ShootingRangeController : AbpController
    {
        protected ShootingRangeController()
        {
            LocalizationResource = typeof(ShootingRangeResource);
        }
    }
}
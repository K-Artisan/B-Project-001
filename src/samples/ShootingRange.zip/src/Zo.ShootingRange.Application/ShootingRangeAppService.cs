﻿using System;
using System.Collections.Generic;
using System.Text;
using Zo.ShootingRange.Localization;
using Volo.Abp.Application.Services;

namespace Zo.ShootingRange
{
    /* Inherit your application services from this class.
     */
    public abstract class ShootingRangeAppService : ApplicationService
    {
        protected ShootingRangeAppService()
        {
            LocalizationResource = typeof(ShootingRangeResource);
        }
    }
}

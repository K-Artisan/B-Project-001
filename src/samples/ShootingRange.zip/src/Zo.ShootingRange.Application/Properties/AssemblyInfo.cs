﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Zo.ShootingRange.Application.Tests")]

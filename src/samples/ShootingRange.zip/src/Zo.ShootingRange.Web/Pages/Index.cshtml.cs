﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;

namespace Zo.ShootingRange.Web.Pages
{
    public class IndexModel : ShootingRangePageModel
    {
        public void OnGet()
        {
            
        }

        public async Task OnPostLoginAsync()
        {
            await HttpContext.ChallengeAsync("oidc");
        }
    }
}
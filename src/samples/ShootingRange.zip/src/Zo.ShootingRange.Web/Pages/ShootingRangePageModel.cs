﻿using Zo.ShootingRange.Localization;
using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace Zo.ShootingRange.Web.Pages
{
    public abstract class ShootingRangePageModel : AbpPageModel
    {
        protected ShootingRangePageModel()
        {
            LocalizationResourceType = typeof(ShootingRangeResource);
        }
    }
}
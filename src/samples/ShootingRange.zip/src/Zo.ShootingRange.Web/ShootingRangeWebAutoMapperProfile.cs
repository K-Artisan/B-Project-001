﻿using AutoMapper;

namespace Zo.ShootingRange.Web
{
    public class ShootingRangeWebAutoMapperProfile : Profile
    {
        public ShootingRangeWebAutoMapperProfile()
        {
            //Define your AutoMapper configuration here for the Web project.
        }
    }
}

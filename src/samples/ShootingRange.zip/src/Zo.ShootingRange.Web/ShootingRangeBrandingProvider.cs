﻿using Volo.Abp.Ui.Branding;
using Volo.Abp.DependencyInjection;

namespace Zo.ShootingRange.Web
{
    [Dependency(ReplaceServices = true)]
    public class ShootingRangeBrandingProvider : DefaultBrandingProvider
    {
        public override string AppName => "ShootingRange";
    }
}

﻿namespace Zo.ShootingRange.Web.Menus
{
    public class ShootingRangeMenus
    {
        private const string Prefix = "ShootingRange";
        public const string Home = Prefix + ".Home";

        //Add your menu items here...

    }
}
﻿using Volo.Abp.AspNetCore.Mvc.Authentication;

namespace Zo.ShootingRange.Web.Controllers
{
    public class AccountController : ChallengeAccountController
    {

    }
}
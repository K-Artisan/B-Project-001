﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Zo.ShootingRange.Web.Tests")]

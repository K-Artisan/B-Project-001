﻿using Volo.Abp;

namespace Zo.ShootingRange.EntityFrameworkCore
{
    public abstract class ShootingRangeEntityFrameworkCoreTestBase : ShootingRangeTestBase<ShootingRangeEntityFrameworkCoreTestModule> 
    {

    }
}

﻿namespace Zo.ShootingRange
{
    public abstract class ShootingRangeApplicationTestBase : ShootingRangeTestBase<ShootingRangeApplicationTestModule> 
    {

    }
}

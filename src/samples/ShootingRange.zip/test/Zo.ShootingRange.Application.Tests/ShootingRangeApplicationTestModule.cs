﻿using Volo.Abp.Modularity;

namespace Zo.ShootingRange
{
    [DependsOn(
        typeof(ShootingRangeApplicationModule),
        typeof(ShootingRangeDomainTestModule)
        )]
    public class ShootingRangeApplicationTestModule : AbpModule
    {

    }
}
﻿namespace Zo.ShootingRange
{
    public abstract class ShootingRangeDomainTestBase : ShootingRangeTestBase<ShootingRangeDomainTestModule> 
    {

    }
}

﻿using Zo.ShootingRange.EntityFrameworkCore;
using Volo.Abp.Modularity;

namespace Zo.ShootingRange
{
    [DependsOn(
        typeof(ShootingRangeEntityFrameworkCoreTestModule)
        )]
    public class ShootingRangeDomainTestModule : AbpModule
    {

    }
}